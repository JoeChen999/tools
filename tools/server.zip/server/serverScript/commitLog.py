import commands
import  sys
import os
import ConfigParser

rootDir='/home/bchen/code/'
VerFile='versions.ini'
branch=sys.argv[1]
gameVer=sys.argv[2]

def getSvnLog(branch, gameVer):
    dir=rootDir+branch+'/'
    os.chdir(dir)
    cf = ConfigParser.ConfigParser()
    cf.read(VerFile)
    gameVersions=cf.options("versions")
    index=0
    for v in gameVersions:
        if v==gameVer:
            revision=cf.get('versions', v)
            break
        index+=1
    if index==0:
        print "there is no record about this version"
        return 0
    elif index==len(gameVersions):
        upResult=commands.getoutput('svn up')
        print upResult
        try:
            pos=upResult.index('revision')
        except:
            print "svn updata failed pls contact Chen Biao"
        i=pos+9
        j=pos+9
        while upResult[j]!='.':
            j+=1
        revision=int(upResult[i:j])
        cf.set('versions',gameVer,revision)
        cf.write(open(VerFile,'w'))
    oldGameVer=gameVersions[index-1]
    oldRevision=int(cf.get('versions', oldGameVer))+1
    logData=commands.getoutput('svn log -r %s:%s'%(oldRevision, revision))
    print  logData
    return 1

if __name__=="__main__":
    result=getSvnLog(branch, gameVer)
    if result!=1:
        print "exception occured"
