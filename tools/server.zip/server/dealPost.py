import commands
def dealData(qs):
    datas=qs.split('&')
    params={}
    for item in datas:
        param=item.split('=')
        if len(param)==2:
            key=param[0]
            value=param[1]
            params[key]=value
        else:
            print 'check your request data, asshole'
    if params['action']=='memcache':
        server=params['servername']
        result=dealMemcache(server)
    elif params['action']=='makeRole':
        mid=params['mid']
        server=params['server']
        result=makeRole(mid, server)
    elif params['action']=='tobepowerful':
        userId=params['userid']
        cityId=params['cityid']
        url=params['url']
        result=toBePowerful(userId, cityId, url)
    elif params['action']=='commitlog':
        branchName=params['branchname']
        gameVersion=params['gameversion']
        result=commitLog(branchName, gameVersion)
    return result
    
        
def dealMemcache(server):
    result=commands.getoutput('php ./serverScript/memFlush.php %s'%server)
    return result

def  makeRole(mid, server):
    result=commands.getoutput('php /opt/www/mobile1/cmdev2/fb/tools/ebox/test/robot/makeNewUser.php %s %s'%(mid, server))
    return result
    
def toBePowerful(userId, cityId, url):
    result=commands.getoutput('python ./serverScript/toBePowerful.py %s %s %s'%(userId, cityId, url))
    return result

def commitLog(branchName, gameVersion):
    result=commands.getoutput('python ./serverScript/commitLog.py %s %s'%(branchName, gameVersion))
    return result
